export const white = '#FFFFFF'
export const black = '#000000'

export const green = {
  green1: '#27AE60',
  green2: '#43d3db'
}

export const red = {
  red1: '#FF6871',
  red2: '#F82D3A'
}

export const yellow = {
  yellow1: '#FFE270',
  yellow2: '#F3841E'
}
